<div id="border-tabel">
<h2>List Resensi</h2>
<table id="example" class="display table table-bordered" width="100%" cellspacing="0">
	<thead>
	<tr>
		<th></th>
		<th>Judul</th>
		<th>Tanggal</th>
		<th>Kategori</th>
        
		<th>Action</th>
	</tr>
	</thead>
	<tbody>
<?php
    $query = mysql_query("
        SELECT * 
        FROM berita INNER JOIN kategori
        ON berita.id_kategori = kategori.id_kategori
    ");
	
	while($row = mysql_fetch_object($query)) {
?>
	<tr>
		<td><img src="img/<?=$row->gambar?>" height="30" /></td>
		<td><?=$row->judul?></td>
		<td><?=$row->tgl?></td>
		<td><?=$row->nm_kategori?></td>
        
		<td><a href="index.php?page=berita&id=<?=$row->id?>">Edit</a> | <a href="proses.php?i=del_berita&id=<?=$row->id?>">Delete</a></td>
	</tr>
<?php
	}
?>
	</tbody>
</table>
</div>


</div>